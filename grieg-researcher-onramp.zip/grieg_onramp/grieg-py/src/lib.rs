use pyo3::{prelude::*, types::PyDict};
use grieg_engine::{eval::{Evaluator, EvalResult}, value::V};
use grieg_parser::parse_expr;

#[pyfunction]
fn eval(py: Python<'_>, expr: &str, mem: bool, ast: bool) -> PyResult<PyObject> {
    let e = parse_expr(expr).map_err(|e| pyo3::exceptions::PyValueError::new_err(format!("{e}")))?;
    let mut ev = Evaluator::new(mem);
    let r: EvalResult = ev.eval(&e, None);
    let out = PyDict::new(py);
    if ast {
        out.set_item("ast", format!("{}", grieg_engine::ast::to_sexpr(&e))).ok();
    }
    let v = match r.value {
        V::Bool(b) => b.into_py(py),
        V::Null => py.None(),
        V::Ident(s) => s.into_py(py), // or py.None() if you prefer
    };
    out.set_item("value", v)?;
    out.set_item("phase", format!("{:?}", r.phase))?;
    Ok(out.into())
}

#[pymodule]
fn grieg(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(eval, m)?)?;
    Ok(())
}
