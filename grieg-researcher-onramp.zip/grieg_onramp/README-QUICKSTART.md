# Researcher Quickstart

```bash
# Build
cargo build --release

# One-shot evaluation
target/release/grieg-cli --expr '@mem(true -> false)' --mem --pretty

# Batch JSONL
target/release/grieg-cli --jsonl docs/samples/expressions.txt --mem --ast > out.jsonl
```

- **Phases**: `ALIVE`, `JAM`, `MEM`, `VAC`
- **Return**: JSON with `value` (true/false/null) and `phase`
- **Spec**: `spec/SPEC.md` • **Lineage**: `docs/lineage.md` • **PDF**: `docs/grieg-main.pdf`

### Optional: emit geometry traces
Build CLI with geometry feature:
```bash
cargo build -p grieg-cli --features emit_geometry
```
Then use `--trace-json` (or your own flag) to dump step records (schema below).
