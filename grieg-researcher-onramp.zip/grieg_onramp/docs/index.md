# Grieg Documentation (preview)

- **Spec**: see `spec/SPEC.md`
- **Lineage**: `docs/lineage.md`
- **Trace schema**: `docs/trace.schema.json`
- **Whitepaper**: `docs/grieg-main.pdf`
