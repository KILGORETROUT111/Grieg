# SECURITY_CONTACT.md
Please report vulnerabilities to **psirt@keemail.me**.
Acknowledgment target: 72h. Coordinated disclosure welcomed.
